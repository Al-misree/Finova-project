"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Shield,
  Zap,
  Globe,
  TrendingUp,
  Wallet,
  Bell,
  Star,
  ChevronDown,
  Menu,
  X,
  Check,
  BarChart3,
  Lock,
  Cpu,
  Users,
  MessageCircle,
  Mail,
  Twitter,
  Github,
  Linkedin,
} from "lucide-react";

const NAV_LINKS = ["Features", "Security", "Pricing", "About", "Contact"];

const FEATURES = [
  {
    icon: Wallet,
    title: "Multi-Wallet Management",
    description: "Connect MetaMask, WalletConnect, and Coinbase Wallet. Track all your assets from one unified dashboard.",
    color: "text-emerald-500",
    bg: "bg-emerald-500/10",
  },
  {
    icon: BarChart3,
    title: "Portfolio Analytics",
    description: "Real-time portfolio tracking with historical performance charts, P&L analysis, and asset allocation.",
    color: "text-blue-500",
    bg: "bg-blue-500/10",
  },
  {
    icon: Cpu,
    title: "AI Financial Insights",
    description: "Powered by Claude AI. Get personalized financial advice, market analysis, and smart savings recommendations.",
    color: "text-purple-500",
    bg: "bg-purple-500/10",
  },
  {
    icon: Shield,
    title: "Bank-Grade Security",
    description: "End-to-end encryption, 2FA, biometric authentication, and real-time fraud detection keep your assets safe.",
    color: "text-amber-500",
    bg: "bg-amber-500/10",
  },
  {
    icon: Globe,
    title: "Global Payments",
    description: "Send and receive payments globally. Support for 50+ currencies and major blockchain networks.",
    color: "text-rose-500",
    bg: "bg-rose-500/10",
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "Real-time alerts for transactions, price movements, security events, and portfolio milestones.",
    color: "text-cyan-500",
    bg: "bg-cyan-500/10",
  },
];

const HOW_IT_WORKS = [
  { step: "01", title: "Create Account", desc: "Sign up with email, verify your identity, and secure your account with 2FA in under 2 minutes." },
  { step: "02", title: "Connect Wallets", desc: "Link your existing crypto wallets or create new ones. Finova supports all major EVM-compatible chains." },
  { step: "03", title: "Track & Grow", desc: "Monitor your portfolio, execute transactions, and use AI-powered insights to optimize your financial strategy." },
];

const TESTIMONIALS = [
  {
    name: "Sarah Chen",
    role: "DeFi Investor",
    avatar: "SC",
    content: "Finova completely transformed how I manage my crypto portfolio. The AI insights are genuinely useful, not just generic advice.",
    rating: 5,
  },
  {
    name: "Marcus Williams",
    role: "Software Engineer",
    avatar: "MW",
    content: "Finally a platform that treats crypto and traditional finance as one unified experience. The UX is exceptional.",
    rating: 5,
  },
  {
    name: "Aisha Patel",
    role: "Financial Analyst",
    avatar: "AP",
    content: "The analytics dashboard alone is worth it. I can see my entire financial picture in one place with charts that actually make sense.",
    rating: 5,
  },
];

const FAQS = [
  {
    question: "Is Finova non-custodial?",
    answer: "Yes. Finova never holds your private keys. We only read on-chain data. Your assets remain fully under your control.",
  },
  {
    question: "Which blockchains are supported?",
    answer: "Finova supports Ethereum, Polygon, Arbitrum, Optimism, Base, and BNB Chain. More networks are added regularly.",
  },
  {
    question: "How secure is my data?",
    answer: "All sensitive data is encrypted at rest and in transit. We use Supabase with Row Level Security, ensuring you only ever see your own data.",
  },
  {
    question: "Can I use Finova on mobile?",
    answer: "Yes. Finova is fully responsive and optimized for mobile, tablet, and desktop browsers.",
  },
  {
    question: "Is there a free plan?",
    answer: "Yes. The Starter plan is completely free with core features. Upgrade to Pro or Enterprise for advanced analytics and higher limits.",
  },
];

const PRICING = [
  {
    name: "Starter",
    price: "Free",
    period: "",
    desc: "For individuals getting started",
    features: ["Up to 3 wallets", "Basic portfolio tracking", "Transaction history", "Email support", "Standard notifications"],
    cta: "Get Started",
    popular: false,
  },
  {
    name: "Pro",
    price: "$12",
    period: "/month",
    desc: "For active crypto traders",
    features: ["Unlimited wallets", "Advanced analytics", "AI financial insights", "Priority support", "Real-time alerts", "Export reports", "Multi-chain support"],
    cta: "Start Free Trial",
    popular: true,
  },
  {
    name: "Enterprise",
    price: "$49",
    period: "/month",
    desc: "For teams and organizations",
    features: ["Everything in Pro", "Team collaboration", "Custom integrations", "Dedicated account manager", "SLA guarantee", "White-label options", "API access"],
    cta: "Contact Sales",
    popular: false,
  },
];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/90 backdrop-blur-xl border-b border-border shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-display font-bold">Finova</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase()}`}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {link}
              </a>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors px-4 py-2"
            >
              Login
            </Link>
            <Link
              href="/register"
              className="btn-primary text-sm px-5 py-2"
            >
              Get Started
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-background/95 backdrop-blur-xl border-b border-border px-4 py-4 space-y-3"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="block text-sm text-muted-foreground hover:text-foreground py-2"
              onClick={() => setMenuOpen(false)}
            >
              {link}
            </a>
          ))}
          <div className="flex flex-col gap-2 pt-3 border-t border-border">
            <Link href="/login" className="btn-secondary w-full justify-center">
              Login
            </Link>
            <Link href="/register" className="btn-primary w-full justify-center">
              Get Started
            </Link>
          </div>
        </motion.div>
      )}
    </header>
  );
}

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 hero-gradient" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(16,185,129,0.05)_0%,_transparent_70%)]" />

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
        style={{
          backgroundImage: `linear-gradient(rgba(16,185,129,1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(16,185,129,1) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-500 text-xs font-medium mb-8">
            <Zap className="w-3 h-3" />
            AI-Powered Financial Platform
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold tracking-tight mb-6">
            Your Money.{" "}
            <span className="gradient-text">Your Crypto.</span>
            <br />
            One Platform.
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed">
            Finova unifies your bank accounts, crypto wallets, and investments
            into one intelligent dashboard. Powered by AI to help you grow wealth smarter.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Link
              href="/register"
              className="btn-primary text-base px-8 py-3 gap-2"
            >
              Start for Free
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#features"
              className="btn-secondary text-base px-8 py-3 gap-2"
            >
              See Features
              <ChevronDown className="w-5 h-5" />
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto">
            {[
              { value: "$2.4B+", label: "Assets Tracked" },
              { value: "120K+", label: "Active Users" },
              { value: "99.9%", label: "Uptime SLA" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-2xl sm:text-3xl font-display font-bold gradient-text">
                  {stat.value}
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Dashboard Preview */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-16 relative"
        >
          <div className="relative mx-auto max-w-5xl">
            <div className="absolute -inset-4 bg-emerald-500/10 blur-3xl rounded-3xl" />
            <div className="relative bg-card border border-border rounded-2xl overflow-hidden shadow-2xl">
              {/* Mock Dashboard Header */}
              <div className="bg-secondary/50 px-6 py-4 flex items-center gap-2 border-b border-border">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-yellow-400" />
                <div className="w-3 h-3 rounded-full bg-green-400" />
                <div className="flex-1 mx-4">
                  <div className="bg-background/60 rounded-md px-3 py-1 text-xs text-muted-foreground text-center">
                    app.finova.io/dashboard
                  </div>
                </div>
              </div>
              {/* Mock Dashboard Content */}
              <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: "Total Balance", value: "$48,291.32", change: "+5.2%", color: "text-emerald-500" },
                  { label: "Crypto Portfolio", value: "$31,840.00", change: "+12.8%", color: "text-emerald-500" },
                  { label: "Connected Wallets", value: "4 Active", change: "3 Networks", color: "text-blue-500" },
                ].map((card) => (
                  <div key={card.label} className="bg-secondary/50 rounded-xl p-4 text-left">
                    <div className="text-xs text-muted-foreground mb-2">{card.label}</div>
                    <div className="text-xl font-display font-bold">{card.value}</div>
                    <div className={`text-xs font-medium mt-1 ${card.color}`}>{card.change}</div>
                  </div>
                ))}
              </div>
              <div className="px-6 pb-6">
                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-sm font-medium">Recent Transactions</span>
                    <span className="text-xs text-muted-foreground">View all</span>
                  </div>
                  {[
                    { label: "ETH → USDC Swap", amount: "-0.5 ETH", status: "Confirmed" },
                    { label: "Received BTC", amount: "+0.02 BTC", status: "Confirmed" },
                    { label: "MATIC Transfer", amount: "-200 MATIC", status: "Pending" },
                  ].map((tx, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                      <div className="text-xs text-muted-foreground">{tx.label}</div>
                      <div className="text-xs font-medium">{tx.amount}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function FeaturesSection() {
  return (
    <section id="features" className="py-24 bg-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">Features</div>
          <h2 className="text-4xl font-display font-bold mb-4">
            Everything you need to manage wealth
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From real-time portfolio tracking to AI-powered financial advice, Finova gives you the tools professionals use.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card border border-border rounded-2xl p-6 card-hover group"
            >
              <div className={`w-12 h-12 rounded-xl ${feature.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className={`w-6 h-6 ${feature.color}`} />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SecuritySection() {
  return (
    <section id="security" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">Security</div>
            <h2 className="text-4xl font-display font-bold mb-6">
              Your assets are protected at every level
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Finova was built with security-first architecture. We never store your private keys,
              use bank-grade encryption, and implement multiple layers of authentication.
            </p>

            <div className="space-y-4">
              {[
                { icon: Lock, title: "Non-Custodial", desc: "Your private keys never leave your device" },
                { icon: Shield, title: "End-to-End Encryption", desc: "AES-256 encryption for all sensitive data" },
                { icon: Users, title: "Row-Level Security", desc: "Database-level isolation — you only see your data" },
                { icon: Zap, title: "Real-Time Monitoring", desc: "24/7 fraud detection and anomaly alerts" },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <item.icon className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">{item.title}</div>
                    <div className="text-muted-foreground text-sm">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute inset-0 bg-emerald-500/5 blur-3xl rounded-3xl" />
            <div className="relative bg-card border border-border rounded-2xl p-8 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Security Score</span>
                <span className="text-emerald-500 font-bold text-lg">98/100</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div className="bg-emerald-500 h-2 rounded-full" style={{ width: "98%" }} />
              </div>
              {[
                { label: "Authentication", score: 100, color: "bg-emerald-500" },
                { label: "Data Encryption", score: 100, color: "bg-emerald-500" },
                { label: "Key Management", score: 98, color: "bg-emerald-500" },
                { label: "Network Security", score: 95, color: "bg-blue-500" },
              ].map((item) => (
                <div key={item.label} className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">{item.label}</span>
                    <span className="font-medium">{item.score}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-1.5">
                    <div
                      className={`${item.color} h-1.5 rounded-full transition-all`}
                      style={{ width: `${item.score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection() {
  return (
    <section className="py-24 bg-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">How It Works</div>
          <h2 className="text-4xl font-display font-bold mb-4">Up and running in minutes</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            No complicated setup, no technical knowledge required. Start managing your wealth in three simple steps.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {HOW_IT_WORKS.map((item, i) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative text-center"
            >
              <div className="text-7xl font-display font-black text-emerald-500/10 mb-4 select-none">
                {item.step}
              </div>
              <h3 className="font-display font-semibold text-xl mb-3">{item.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  return (
    <section className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">Testimonials</div>
          <h2 className="text-4xl font-display font-bold">Trusted by thousands</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card border border-border rounded-2xl p-6"
            >
              <div className="flex mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">{t.content}</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-500 flex items-center justify-center text-sm font-bold">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-sm font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQSection() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section className="py-24 bg-secondary/20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">FAQ</div>
          <h2 className="text-4xl font-display font-bold">Common questions</h2>
        </motion.div>

        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border rounded-xl overflow-hidden"
            >
              <button
                className="w-full flex items-center justify-between px-6 py-4 text-left text-sm font-medium hover:bg-secondary/30 transition-colors"
                onClick={() => setOpen(open === i ? null : i)}
              >
                {faq.question}
                <ChevronDown
                  className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ml-4 ${
                    open === i ? "rotate-180" : ""
                  }`}
                />
              </button>
              {open === i && (
                <div className="px-6 pb-4 text-sm text-muted-foreground leading-relaxed">
                  {faq.answer}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PricingSection() {
  return (
    <section id="pricing" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">Pricing</div>
          <h2 className="text-4xl font-display font-bold mb-4">Simple, transparent pricing</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Start free. Scale when you need to. No hidden fees, no surprises.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {PRICING.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative bg-card border rounded-2xl p-8 ${
                plan.popular
                  ? "border-emerald-500 shadow-lg shadow-emerald-500/10"
                  : "border-border"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <div className="bg-emerald-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                    Most Popular
                  </div>
                </div>
              )}
              <div className="mb-6">
                <h3 className="font-display font-bold text-xl mb-1">{plan.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">{plan.desc}</p>
                <div className="flex items-end gap-1">
                  <span className="text-4xl font-display font-black">{plan.price}</span>
                  <span className="text-muted-foreground pb-1">{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm">
                    <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span className="text-muted-foreground">{f}</span>
                  </li>
                ))}
              </ul>

              <Link
                href="/register"
                className={`w-full flex items-center justify-center py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                  plan.popular
                    ? "bg-emerald-500 text-white hover:bg-emerald-600"
                    : "border border-border hover:bg-secondary"
                }`}
              >
                {plan.cta}
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function AboutSection() {
  return (
    <section id="about" className="py-24 bg-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">About</div>
            <h2 className="text-4xl font-display font-bold mb-6">
              Built for the future of finance
            </h2>
            <p className="text-muted-foreground mb-4 leading-relaxed">
              Finova was founded with a simple belief: managing money shouldn't require a finance degree or a team of advisors. We built the tools we wished existed.
            </p>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Our platform bridges traditional banking and Web3, giving you a unified view of your entire financial picture powered by AI that actually understands your goals.
            </p>
            <div className="grid grid-cols-2 gap-6">
              {[
                { value: "2022", label: "Founded" },
                { value: "50+", label: "Team Members" },
                { value: "12", label: "Countries" },
                { value: "4.9★", label: "App Rating" },
              ].map((stat) => (
                <div key={stat.label} className="bg-card border border-border rounded-xl p-4">
                  <div className="text-2xl font-display font-bold gradient-text">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-emerald-500/5 blur-3xl rounded-3xl" />
            <div className="relative grid grid-cols-2 gap-4">
              {[
                { icon: TrendingUp, title: "Performance", desc: "Built for speed and reliability" },
                { icon: Shield, title: "Security", desc: "Enterprise-grade protection" },
                { icon: Globe, title: "Global", desc: "Works anywhere in the world" },
                { icon: Cpu, title: "AI-Native", desc: "Intelligence in every feature" },
              ].map((item) => (
                <div key={item.title} className="bg-card border border-border rounded-2xl p-5 card-hover">
                  <item.icon className="w-6 h-6 text-emerald-500 mb-3" />
                  <div className="font-semibold text-sm mb-1">{item.title}</div>
                  <div className="text-xs text-muted-foreground">{item.desc}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section id="contact" className="py-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="text-emerald-500 text-sm font-semibold uppercase tracking-wider mb-3">Contact</div>
          <h2 className="text-4xl font-display font-bold mb-4">Get in touch</h2>
          <p className="text-muted-foreground mb-10">
            Have questions? Our team is ready to help you get started.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
            {[
              { icon: Mail, label: "Email", value: "hello@finova.app" },
              { icon: MessageCircle, label: "Live Chat", value: "Available 24/7" },
              { icon: Twitter, label: "Twitter", value: "@finovaapp" },
            ].map((item) => (
              <div key={item.label} className="bg-card border border-border rounded-xl p-5 text-center">
                <item.icon className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                <div className="text-xs text-muted-foreground mb-1">{item.label}</div>
                <div className="text-sm font-medium">{item.value}</div>
              </div>
            ))}
          </div>

          <Link href="/register" className="btn-primary text-base px-10 py-3 gap-2">
            Start Free Today
            <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center">
                <TrendingUp className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-display font-bold">Finova</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              AI-powered financial management for the Web3 era.
            </p>
            <div className="flex gap-3 mt-4">
              {[Twitter, Github, Linkedin].map((Icon, i) => (
                <button key={i} className="w-8 h-8 rounded-lg border border-border hover:bg-secondary transition-colors flex items-center justify-center">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>

          {[
            { title: "Product", links: ["Features", "Security", "Pricing", "Changelog"] },
            { title: "Company", links: ["About", "Blog", "Careers", "Press"] },
            { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Cookie Policy", "Compliance"] },
          ].map((col) => (
            <div key={col.title}>
              <h4 className="font-semibold text-sm mb-4">{col.title}</h4>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-border flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Finova Technologies Ltd. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Not financial advice. Always DYOR.
          </p>
        </div>
      </div>
    </footer>
  );
}

export function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <SecuritySection />
      <HowItWorksSection />
      <TestimonialsSection />
      <FAQSection />
      <PricingSection />
      <AboutSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
