"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { Loader2, Save, Camera, Mail, Calendar } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { updateProfileSchema, type UpdateProfileFormData } from "@/lib/validations";
import { formatDate, generateAvatar } from "@/lib/utils";
import type { Profile } from "@/lib/types";

export function ProfileView({ profile, email, userId }: { profile: Profile | null; email: string; userId: string }) {
  const [loading, setLoading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || "");
  const [uploading, setUploading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<UpdateProfileFormData>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      full_name: profile?.full_name || "",
      phone: profile?.phone || "",
      bio: profile?.bio || "",
      country: profile?.country || "",
      currency: profile?.currency || "USD",
    },
  });

  const displayName = profile?.full_name || email.split("@")[0];
  const initials = generateAvatar(displayName);

  const onSubmit = async (data: UpdateProfileFormData) => {
    setLoading(true);
    const supabase = createClient();
    const { error } = await supabase.from("profiles").update(data).eq("id", userId);
    if (error) { toast.error(error.message); setLoading(false); return; }
    toast.success("Profile updated successfully");
    setLoading(false);
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { toast.error("Image must be under 2MB"); return; }

    setUploading(true);
    const supabase = createClient();
    const fileExt = file.name.split(".").pop();
    const filePath = `${userId}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, file, { upsert: true });

    if (uploadError) {
      toast.error("Upload failed. Make sure the 'avatars' storage bucket exists in Supabase.");
      setUploading(false);
      return;
    }

    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(filePath);
    const publicUrl = `${urlData.publicUrl}?t=${Date.now()}`;

    await supabase.from("profiles").update({ avatar_url: publicUrl }).eq("id", userId);
    setAvatarUrl(publicUrl);
    toast.success("Avatar updated!");
    setUploading(false);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="page-header">
        <h1 className="page-title">Profile</h1>
        <p className="page-subtitle">Manage your personal information</p>
      </div>

      {/* Avatar Card */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 text-emerald-500 flex items-center justify-center text-2xl font-bold overflow-hidden">
              {avatarUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              ) : (
                initials
              )}
            </div>
            <label className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center cursor-pointer hover:bg-emerald-600 transition-colors">
              {uploading ? (
                <Loader2 className="w-3.5 h-3.5 text-white animate-spin" />
              ) : (
                <Camera className="w-3.5 h-3.5 text-white" />
              )}
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
            </label>
          </div>
          <div>
            <h2 className="font-display font-semibold text-lg">{displayName}</h2>
            <p className="text-sm text-muted-foreground flex items-center gap-1.5 mt-1">
              <Mail className="w-3.5 h-3.5" /> {email}
            </p>
            <p className="text-xs text-muted-foreground flex items-center gap-1.5 mt-1">
              <Calendar className="w-3 h-3" /> Joined {profile?.created_at ? formatDate(profile.created_at) : "—"}
            </p>
          </div>
        </div>
      </motion.div>

      {/* Edit Form */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card border border-border rounded-2xl p-6">
        <h2 className="font-display font-semibold text-lg mb-5">Personal Information</h2>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Full Name</label>
            <input {...register("full_name")} className={`input-field ${errors.full_name ? "border-destructive" : ""}`} />
            {errors.full_name && <p className="text-xs text-destructive mt-1">{errors.full_name.message}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Phone Number</label>
              <input {...register("phone")} placeholder="+234 800 000 0000" className="input-field" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Country</label>
              <input {...register("country")} placeholder="Nigeria" className="input-field" />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">Preferred Currency</label>
            <select {...register("currency")} className="input-field">
              <option value="USD">USD - US Dollar</option>
              <option value="EUR">EUR - Euro</option>
              <option value="GBP">GBP - British Pound</option>
              <option value="NGN">NGN - Nigerian Naira</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium mb-1.5 block">Bio</label>
            <textarea {...register("bio")} rows={3} placeholder="Tell us about yourself..." className={`input-field resize-none ${errors.bio ? "border-destructive" : ""}`} />
            {errors.bio && <p className="text-xs text-destructive mt-1">{errors.bio.message}</p>}
          </div>

          <div className="flex justify-end pt-2">
            <button type="submit" disabled={loading} className="btn-primary gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {loading ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
