"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Wallet, Plus, Trash2, Star, ExternalLink, Copy, Check, Loader2, Globe } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { formatAddress, formatRelativeTime } from "@/lib/utils";
import type { Wallet as WalletType } from "@/lib/types";

const WALLET_ICONS: Record<string, string> = {
  metamask: "🦊",
  walletconnect: "🔗",
  coinbase: "🔵",
  manual: "👜",
};

interface WalletsViewProps {
  wallets: WalletType[];
  userId: string;
}

function AddWalletModal({ onClose, onAdd }: { onClose: () => void; onAdd: (w: Partial<WalletType>) => Promise<void> }) {
  const [form, setForm] = useState({ address: "", wallet_type: "manual", network: "ethereum", label: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!form.address.match(/^0x[a-fA-F0-9]{40}$/)) {
      toast.error("Invalid Ethereum address format");
      return;
    }
    setLoading(true);
    await onAdd(form);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-border rounded-2xl p-6 w-full max-w-md shadow-xl"
      >
        <h2 className="font-display font-bold text-xl mb-1">Add Wallet</h2>
        <p className="text-muted-foreground text-sm mb-6">Connect or import a crypto wallet</p>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Wallet Address *</label>
            <input
              value={form.address}
              onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
              placeholder="0x..."
              className="input-field font-mono text-xs"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Wallet Type</label>
            <select
              value={form.wallet_type}
              onChange={e => setForm(f => ({ ...f, wallet_type: e.target.value }))}
              className="input-field"
            >
              <option value="metamask">MetaMask</option>
              <option value="walletconnect">WalletConnect</option>
              <option value="coinbase">Coinbase Wallet</option>
              <option value="manual">Manual Import</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Network</label>
            <select
              value={form.network}
              onChange={e => setForm(f => ({ ...f, network: e.target.value }))}
              className="input-field"
            >
              <option value="ethereum">Ethereum</option>
              <option value="polygon">Polygon</option>
              <option value="arbitrum">Arbitrum</option>
              <option value="optimism">Optimism</option>
              <option value="base">Base</option>
              <option value="bnb">BNB Chain</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Label (optional)</label>
            <input
              value={form.label}
              onChange={e => setForm(f => ({ ...f, label: e.target.value }))}
              placeholder="e.g. Trading Wallet"
              className="input-field"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary flex-1 gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {loading ? "Adding..." : "Add Wallet"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export function WalletsView({ wallets: initialWallets, userId }: WalletsViewProps) {
  const [wallets, setWallets] = useState(initialWallets);
  const [showModal, setShowModal] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopied(address);
    toast.success("Address copied!");
    setTimeout(() => setCopied(null), 2000);
  };

  const handleAddWallet = async (data: Partial<WalletType>) => {
    const supabase = createClient();
    const { data: wallet, error } = await supabase
      .from("wallets")
      .insert({ ...data, user_id: userId })
      .select()
      .single();

    if (error) {
      if (error.code === "23505") toast.error("This wallet address is already connected");
      else toast.error(error.message);
      return;
    }
    setWallets(prev => [wallet, ...prev]);
    setShowModal(false);
    toast.success("Wallet connected successfully!");
  };

  const handleDelete = async (id: string) => {
    const supabase = createClient();
    const { error } = await supabase.from("wallets").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    setWallets(prev => prev.filter(w => w.id !== id));
    toast.success("Wallet removed");
  };

  const handleSetPrimary = async (id: string) => {
    const supabase = createClient();
    await supabase.from("wallets").update({ is_primary: false }).eq("user_id", userId);
    await supabase.from("wallets").update({ is_primary: true }).eq("id", id);
    setWallets(prev => prev.map(w => ({ ...w, is_primary: w.id === id })));
    toast.success("Primary wallet updated");
  };

  return (
    <div className="space-y-6">
      {showModal && (
        <AddWalletModal onClose={() => setShowModal(false)} onAdd={handleAddWallet} />
      )}

      <div className="flex items-center justify-between page-header">
        <div>
          <h1 className="page-title">Wallets</h1>
          <p className="page-subtitle">{wallets.length} wallet{wallets.length !== 1 ? "s" : ""} connected</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary gap-2">
          <Plus className="w-4 h-4" />
          Add Wallet
        </button>
      </div>

      {wallets.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-16 text-center">
          <Wallet className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-display font-semibold text-lg mb-2">No wallets connected</h3>
          <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
            Connect your MetaMask, WalletConnect, or Coinbase Wallet to start tracking your crypto portfolio.
          </p>
          <button onClick={() => setShowModal(true)} className="btn-primary gap-2">
            <Plus className="w-4 h-4" />
            Connect Your First Wallet
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {wallets.map((wallet, i) => (
            <motion.div
              key={wallet.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border rounded-2xl p-5 hover:border-emerald-500/30 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{WALLET_ICONS[wallet.wallet_type] || "👜"}</div>
                  <div>
                    <p className="font-semibold text-sm capitalize">{wallet.wallet_type}</p>
                    <p className="text-xs text-muted-foreground">{wallet.label || wallet.network}</p>
                  </div>
                </div>
                {wallet.is_primary && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center gap-1">
                    <Star className="w-3 h-3 fill-emerald-500" /> Primary
                  </span>
                )}
              </div>

              <div className="bg-secondary/50 rounded-xl px-3 py-2.5 mb-4 flex items-center justify-between gap-2">
                <code className="text-xs font-mono truncate text-muted-foreground">
                  {formatAddress(wallet.address, 6)}
                </code>
                <button
                  onClick={() => copyAddress(wallet.address)}
                  className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {copied === wallet.address ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground capitalize">{wallet.network}</span>
                <span className="text-muted-foreground/30">·</span>
                <span className="text-xs text-muted-foreground">Connected {formatRelativeTime(wallet.connected_at)}</span>
              </div>

              <div className="flex gap-2">
                {!wallet.is_primary && (
                  <button
                    onClick={() => handleSetPrimary(wallet.id)}
                    className="flex-1 text-xs btn-secondary py-1.5 gap-1"
                  >
                    <Star className="w-3 h-3" />
                    Set Primary
                  </button>
                )}
                <a
                  href={`https://etherscan.io/address/${wallet.address}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 text-xs btn-secondary py-1.5 gap-1 justify-center flex items-center"
                >
                  <ExternalLink className="w-3 h-3" />
                  Explorer
                </a>
                <button
                  onClick={() => handleDelete(wallet.id)}
                  className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
