"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, ArrowDownLeft, ArrowLeftRight, Search, Activity } from "lucide-react";
import { formatCurrency, formatAddress, formatDateTime, cn } from "@/lib/utils";
import type { Transaction } from "@/lib/types";

const TYPE_ICONS: Record<string, React.ElementType> = {
  send: ArrowUpRight,
  receive: ArrowDownLeft,
  swap: ArrowLeftRight,
  stake: ArrowUpRight,
  unstake: ArrowDownLeft,
  approve: Activity,
  mint: ArrowDownLeft,
  burn: ArrowUpRight,
};

const STATUS_STYLES: Record<string, string> = {
  confirmed: "badge-status-resolved",
  pending: "badge-status-pending",
  failed: "badge-status-failed",
  cancelled: "bg-muted text-muted-foreground",
};

export function TransactionsView({ transactions }: { transactions: Transaction[] }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const filtered = transactions.filter(tx => {
    const matchSearch =
      !search ||
      tx.tx_hash?.toLowerCase().includes(search.toLowerCase()) ||
      tx.currency.toLowerCase().includes(search.toLowerCase()) ||
      tx.from_address?.toLowerCase().includes(search.toLowerCase()) ||
      tx.to_address?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || tx.status === statusFilter;
    const matchType = typeFilter === "all" || tx.type === typeFilter;
    return matchSearch && matchStatus && matchType;
  });

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Transactions</h1>
        <p className="page-subtitle">{transactions.length} total transactions</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by hash, currency, address..."
            className="input-field pl-9"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="input-field w-auto"
          >
            <option value="all">All Status</option>
            <option value="confirmed">Confirmed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="input-field w-auto"
          >
            <option value="all">All Types</option>
            <option value="send">Send</option>
            <option value="receive">Receive</option>
            <option value="swap">Swap</option>
            <option value="stake">Stake</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <Activity className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm font-medium text-muted-foreground">
              {transactions.length === 0 ? "No transactions yet" : "No transactions match your filters"}
            </p>
            {transactions.length === 0 && (
              <p className="text-xs text-muted-foreground mt-1">Connect a wallet to start tracking activity</p>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Type</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Amount</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden md:table-cell">Hash</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden lg:table-cell">Network</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((tx, i) => {
                  const Icon = TYPE_ICONS[tx.type] || Activity;
                  const isReceive = tx.type === "receive" || tx.type === "unstake" || tx.type === "mint";
                  return (
                    <motion.tr
                      key={tx.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.02 }}
                      className="hover:bg-secondary/30 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0",
                            isReceive ? "bg-emerald-500/10" : "bg-secondary"
                          )}>
                            <Icon className={cn("w-4 h-4", isReceive ? "text-emerald-500" : "text-muted-foreground")} />
                          </div>
                          <span className="text-sm font-medium capitalize">{tx.type}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className={cn("text-sm font-semibold", isReceive ? "text-emerald-500" : "")}>
                          {isReceive ? "+" : "-"}{tx.amount} {tx.currency}
                        </p>
                        {tx.usd_value && (
                          <p className="text-xs text-muted-foreground">{formatCurrency(tx.usd_value)}</p>
                        )}
                      </td>
                      <td className="px-6 py-4 hidden md:table-cell">
                        <code className="text-xs text-muted-foreground font-mono">
                          {tx.tx_hash ? formatAddress(tx.tx_hash) : "—"}
                        </code>
                      </td>
                      <td className="px-6 py-4 hidden lg:table-cell">
                        <span className="text-xs capitalize text-muted-foreground">{tx.network}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border",
                          STATUS_STYLES[tx.status]
                        )}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 hidden sm:table-cell">
                        <span className="text-xs text-muted-foreground">{formatDateTime(tx.created_at)}</span>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
