"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, MessageCircle, Loader2, X } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { createTicketSchema, type CreateTicketFormData } from "@/lib/validations";
import { formatRelativeTime, cn } from "@/lib/utils";
import type { SupportTicket } from "@/lib/types";

const PRIORITY_STYLES: Record<string, string> = {
  low: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  medium: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  high: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  urgent: "bg-red-500/10 text-red-500 border-red-500/20",
};
const STATUS_STYLES: Record<string, string> = {
  open: "badge-status-open",
  in_progress: "badge-status-pending",
  resolved: "badge-status-resolved",
  closed: "bg-muted text-muted-foreground",
};

export function SupportView({ tickets: init, userId }: { tickets: SupportTicket[]; userId: string }) {
  const [tickets, setTickets] = useState(init);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateTicketFormData>({
    resolver: zodResolver(createTicketSchema),
    defaultValues: { category: "general", priority: "medium" },
  });

  const onSubmit = async (data: CreateTicketFormData) => {
    setLoading(true);
    const supabase = createClient();
    const { data: ticket, error } = await supabase
      .from("support_tickets")
      .insert({ ...data, user_id: userId })
      .select()
      .single();
    if (error) { toast.error(error.message); setLoading(false); return; }
    setTickets(prev => [ticket, ...prev]);
    reset();
    setShowForm(false);
    toast.success(`Ticket ${ticket.ticket_number} created`);
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between page-header">
        <div>
          <h1 className="page-title">Support</h1>
          <p className="page-subtitle">{tickets.length} ticket{tickets.length !== 1 ? "s" : ""} total</p>
        </div>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary gap-2">
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? "Cancel" : "New Ticket"}
        </button>
      </div>

      {/* New Ticket Form */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <h2 className="font-display font-semibold text-lg mb-4">Create Support Ticket</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Category</label>
                <select {...register("category")} className="input-field">
                  <option value="general">General</option>
                  <option value="technical">Technical</option>
                  <option value="billing">Billing</option>
                  <option value="security">Security</option>
                  <option value="wallet">Wallet</option>
                  <option value="account">Account</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Priority</label>
                <select {...register("priority")} className="input-field">
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Subject *</label>
              <input {...register("subject")} placeholder="Brief description of your issue" className={`input-field ${errors.subject ? "border-destructive" : ""}`} />
              {errors.subject && <p className="text-xs text-destructive mt-1">{errors.subject.message}</p>}
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Message *</label>
              <textarea
                {...register("message")}
                rows={5}
                placeholder="Describe your issue in detail..."
                className={`input-field resize-none ${errors.message ? "border-destructive" : ""}`}
              />
              {errors.message && <p className="text-xs text-destructive mt-1">{errors.message.message}</p>}
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
              <button type="submit" disabled={loading} className="btn-primary gap-2">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {loading ? "Submitting..." : "Submit Ticket"}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Tickets list */}
      {tickets.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-16 text-center">
          <MessageCircle className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-semibold text-lg mb-2">No support tickets</h3>
          <p className="text-muted-foreground text-sm mb-6">Having an issue? Our team is ready to help.</p>
          <button onClick={() => setShowForm(true)} className="btn-primary gap-2">
            <Plus className="w-4 h-4" /> Create First Ticket
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {tickets.map((ticket, i) => (
            <motion.div
              key={ticket.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="bg-card border border-border rounded-xl p-5 hover:border-emerald-500/20 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs font-mono text-muted-foreground">{ticket.ticket_number}</span>
                    <span className={cn("text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border", STATUS_STYLES[ticket.status])}>
                      {ticket.status.replace("_", " ")}
                    </span>
                    <span className={cn("text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border", PRIORITY_STYLES[ticket.priority])}>
                      {ticket.priority}
                    </span>
                  </div>
                  <h3 className="font-semibold text-sm">{ticket.subject}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{ticket.message}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-muted-foreground capitalize">{ticket.category}</p>
                  <p className="text-xs text-muted-foreground mt-1">{formatRelativeTime(ticket.created_at)}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
