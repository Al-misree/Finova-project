"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  Activity,
  Plus,
  ArrowRight,
  Bell,
  Shield,
  BarChart3,
} from "lucide-react";
import { formatCurrency, formatAddress, formatRelativeTime, cn } from "@/lib/utils";
import type { Profile, Wallet as WalletType, Transaction, Notification } from "@/lib/types";

interface DashboardOverviewProps {
  profile: Profile | null;
  wallets: WalletType[];
  transactions: Transaction[];
  unreadNotifications: Notification[];
}

const MOCK_PORTFOLIO = [
  { symbol: "ETH", name: "Ethereum", amount: 2.45, value: 8120, change: 5.2, positive: true },
  { symbol: "BTC", name: "Bitcoin", amount: 0.08, value: 5280, change: 2.1, positive: true },
  { symbol: "USDC", name: "USD Coin", amount: 3200, value: 3200, change: 0.0, positive: true },
  { symbol: "MATIC", name: "Polygon", amount: 1500, value: 1350, change: -3.4, positive: false },
];

function StatCard({ label, value, subtext, icon: Icon, trend, color = "emerald" }: {
  label: string;
  value: string;
  subtext?: string;
  icon: React.ElementType;
  trend?: { value: string; positive: boolean };
  color?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="stat-card"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl bg-${color}-500/10 flex items-center justify-center`}>
          <Icon className={`w-5 h-5 text-${color}-500`} />
        </div>
        {trend && (
          <span className={cn(
            "text-xs font-semibold px-2 py-0.5 rounded-full",
            trend.positive
              ? "bg-emerald-500/10 text-emerald-500"
              : "bg-red-500/10 text-red-500"
          )}>
            {trend.positive ? "+" : ""}{trend.value}
          </span>
        )}
      </div>
      <div className="text-2xl font-display font-bold mb-1">{value}</div>
      <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{label}</div>
      {subtext && <div className="text-xs text-muted-foreground mt-1">{subtext}</div>}
    </motion.div>
  );
}

export function DashboardOverview({ profile, wallets, transactions, unreadNotifications }: DashboardOverviewProps) {
  const totalPortfolioValue = MOCK_PORTFOLIO.reduce((acc, a) => acc + a.value, 0);
  const hasWallets = wallets.length > 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">
          {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label="Total Balance"
          value={formatCurrency(totalPortfolioValue)}
          icon={BarChart3}
          trend={{ value: "8.4%", positive: true }}
          color="emerald"
        />
        <StatCard
          label="Connected Wallets"
          value={wallets.length.toString()}
          subtext={hasWallets ? "Active connections" : "No wallets connected"}
          icon={Wallet}
          color="blue"
        />
        <StatCard
          label="Transactions"
          value={transactions.length.toString()}
          subtext="This month"
          icon={Activity}
          color="purple"
        />
        <StatCard
          label="Notifications"
          value={unreadNotifications.length.toString()}
          subtext="Unread alerts"
          icon={Bell}
          color="amber"
        />
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Portfolio */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-2 bg-card border border-border rounded-2xl overflow-hidden"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-border">
            <h2 className="font-display font-semibold text-lg">Portfolio</h2>
            <Link href="/wallets" className="text-xs text-emerald-500 hover:text-emerald-400 font-medium flex items-center gap-1">
              Manage <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="p-6">
            <div className="flex items-end justify-between mb-6">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Value</p>
                <p className="text-4xl font-display font-bold">{formatCurrency(totalPortfolioValue)}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">24h Change</p>
                <p className="text-lg font-semibold text-emerald-500 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  +$842.50 (8.4%)
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {MOCK_PORTFOLIO.map((asset) => (
                <div key={asset.symbol} className="flex items-center gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-sm font-bold flex-shrink-0">
                    {asset.symbol.slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{asset.name}</p>
                    <p className="text-xs text-muted-foreground">{asset.amount} {asset.symbol}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">{formatCurrency(asset.value)}</p>
                    <p className={cn("text-xs font-medium", asset.positive ? "text-emerald-500" : "text-red-500")}>
                      {asset.positive ? "+" : ""}{asset.change}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Account Status */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card border border-border rounded-2xl p-5"
          >
            <h3 className="font-semibold text-sm mb-4">Account Status</h3>
            <div className="space-y-3">
              {[
                { label: "Email Verified", status: true },
                { label: "Profile Complete", status: !!profile?.full_name },
                { label: "Wallet Connected", status: hasWallets },
                { label: "2FA Enabled", status: false },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{item.label}</span>
                  <span className={cn(
                    "text-xs font-semibold px-2 py-0.5 rounded-full",
                    item.status ? "bg-emerald-500/10 text-emerald-500" : "bg-muted text-muted-foreground"
                  )}>
                    {item.status ? "Active" : "Pending"}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card border border-border rounded-2xl p-5"
          >
            <h3 className="font-semibold text-sm mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Connect Wallet", icon: Wallet, href: "/wallets", color: "text-blue-500 bg-blue-500/10" },
                { label: "View Transactions", icon: Activity, href: "/transactions", color: "text-purple-500 bg-purple-500/10" },
                { label: "Open Ticket", icon: Plus, href: "/support", color: "text-amber-500 bg-amber-500/10" },
                { label: "Security", icon: Shield, href: "/settings", color: "text-rose-500 bg-rose-500/10" },
              ].map((action) => (
                <Link
                  key={action.label}
                  href={action.href}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-secondary transition-colors text-center group"
                >
                  <div className={`w-9 h-9 rounded-xl ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <action.icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-medium leading-tight">{action.label}</span>
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Recent Transactions */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-card border border-border rounded-2xl overflow-hidden"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-display font-semibold text-lg">Recent Transactions</h2>
          <Link href="/transactions" className="text-xs text-emerald-500 hover:text-emerald-400 font-medium flex items-center gap-1">
            View all <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="divide-y divide-border">
          {transactions.length > 0 ? (
            transactions.slice(0, 5).map((tx) => (
              <div key={tx.id} className="flex items-center gap-4 px-6 py-4 hover:bg-secondary/30 transition-colors">
                <div className={cn(
                  "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0",
                  tx.type === "receive" ? "bg-emerald-500/10" : "bg-secondary"
                )}>
                  {tx.type === "receive" ? (
                    <ArrowDownLeft className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium capitalize">{tx.type}</p>
                  <p className="text-xs text-muted-foreground">
                    {tx.tx_hash ? formatAddress(tx.tx_hash) : "—"} · {formatRelativeTime(tx.created_at)}
                  </p>
                </div>
                <div className="text-right">
                  <p className={cn("text-sm font-semibold", tx.type === "receive" ? "text-emerald-500" : "")}>
                    {tx.type === "receive" ? "+" : "-"}{tx.amount} {tx.currency}
                  </p>
                  <span className={cn(
                    "text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded",
                    tx.status === "confirmed" ? "badge-status-resolved" :
                    tx.status === "pending" ? "badge-status-pending" : "badge-status-failed"
                  )}>
                    {tx.status}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-12 text-center">
              <Activity className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground font-medium">No transactions yet</p>
              <p className="text-xs text-muted-foreground mt-1">Connect a wallet to start tracking your activity</p>
              <Link href="/wallets" className="btn-primary mt-4 text-xs px-5 py-2 gap-1.5 inline-flex">
                <Plus className="w-3.5 h-3.5" />
                Connect Wallet
              </Link>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
