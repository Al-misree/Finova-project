"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { Shield, Bell, Lock, Trash2, Loader2, AlertTriangle, Moon, Mail } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { useTheme } from "next-themes";

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`w-11 h-6 rounded-full transition-colors relative flex-shrink-0 ${checked ? "bg-emerald-500" : "bg-secondary"}`}
    >
      <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform shadow-sm ${checked ? "translate-x-5" : "translate-x-0"}`} />
    </button>
  );
}

export function SettingsView({ email, userId }: { email: string; userId: string }) {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifPush, setNotifPush] = useState(true);
  const [notifSecurity, setNotifSecurity] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);

  const handleChangePassword = async () => {
    setChangingPassword(true);
    const supabase = createClient();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) toast.error(error.message);
    else toast.success("Password reset link sent to your email");
    setChangingPassword(false);
  };

  const handleDeleteAccount = async () => {
    setDeleting(true);
    const supabase = createClient();
    // Note: actual account deletion requires a server-side admin API call.
    // This signs the user out and informs them to contact support for full deletion.
    await supabase.auth.signOut();
    toast.success("Account deletion requested. You've been signed out.");
    router.push("/");
    setDeleting(false);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="page-header">
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Manage your account preferences and security</p>
      </div>

      {/* Appearance */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Moon className="w-4 h-4 text-emerald-500" />
          <h2 className="font-display font-semibold text-lg">Appearance</h2>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Dark Mode</p>
            <p className="text-xs text-muted-foreground">Toggle between light and dark theme</p>
          </div>
          <Toggle checked={theme === "dark"} onChange={(v) => setTheme(v ? "dark" : "light")} />
        </div>
      </motion.div>

      {/* Notifications */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Bell className="w-4 h-4 text-emerald-500" />
          <h2 className="font-display font-semibold text-lg">Notifications</h2>
        </div>
        <div className="space-y-4">
          {[
            { label: "Email Notifications", desc: "Receive updates via email", value: notifEmail, set: setNotifEmail },
            { label: "Push Notifications", desc: "Receive in-app push alerts", value: notifPush, set: setNotifPush },
            { label: "Security Alerts", desc: "Get notified of suspicious activity", value: notifSecurity, set: setNotifSecurity },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
              <Toggle checked={item.value} onChange={item.set} />
            </div>
          ))}
        </div>
      </motion.div>

      {/* Security */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Shield className="w-4 h-4 text-emerald-500" />
          <h2 className="font-display font-semibold text-lg">Security</h2>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/30">
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">{email}</p>
                <p className="text-xs text-emerald-500">Verified</p>
              </div>
            </div>
          </div>
          <button
            onClick={handleChangePassword}
            disabled={changingPassword}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-secondary/50 transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Change Password</p>
                <p className="text-xs text-muted-foreground">Send a password reset link to your email</p>
              </div>
            </div>
            {changingPassword && <Loader2 className="w-4 h-4 animate-spin" />}
          </button>
          <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/30">
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Two-Factor Authentication</p>
                <p className="text-xs text-muted-foreground">Add an extra layer of security</p>
              </div>
            </div>
            <span className="text-xs font-semibold px-2 py-1 rounded-full bg-muted text-muted-foreground">Coming soon</span>
          </div>
        </div>
      </motion.div>

      {/* Danger Zone */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card border border-destructive/30 rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <AlertTriangle className="w-4 h-4 text-destructive" />
          <h2 className="font-display font-semibold text-lg text-destructive">Danger Zone</h2>
        </div>
        {!showDeleteConfirm ? (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 text-sm font-medium text-destructive hover:bg-destructive/10 px-4 py-2 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Delete Account
          </button>
        ) : (
          <div className="bg-destructive/5 border border-destructive/20 rounded-xl p-4">
            <p className="text-sm font-medium mb-1">Are you absolutely sure?</p>
            <p className="text-xs text-muted-foreground mb-4">
              This action cannot be undone. This will permanently delete your account and remove all your data.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowDeleteConfirm(false)} className="btn-secondary text-sm">Cancel</button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              >
                {deleting && <Loader2 className="w-4 h-4 animate-spin" />}
                {deleting ? "Processing..." : "Yes, delete my account"}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
