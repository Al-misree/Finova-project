"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Bell, CheckCheck, Info, CheckCircle, AlertTriangle, XCircle, ArrowLeftRight, Shield } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { formatRelativeTime, cn } from "@/lib/utils";
import type { Notification } from "@/lib/types";

const TYPE_CONFIG: Record<string, { icon: React.ElementType; color: string }> = {
  info: { icon: Info, color: "text-blue-500 bg-blue-500/10" },
  success: { icon: CheckCircle, color: "text-emerald-500 bg-emerald-500/10" },
  warning: { icon: AlertTriangle, color: "text-amber-500 bg-amber-500/10" },
  error: { icon: XCircle, color: "text-red-500 bg-red-500/10" },
  transaction: { icon: ArrowLeftRight, color: "text-purple-500 bg-purple-500/10" },
  security: { icon: Shield, color: "text-rose-500 bg-rose-500/10" },
};

export function NotificationsView({ notifications: init }: { notifications: Notification[] }) {
  const [notifications, setNotifications] = useState(init);
  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = async (id: string) => {
    const supabase = createClient();
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllAsRead = async () => {
    const supabase = createClient();
    const unreadIds = notifications.filter(n => !n.read).map(n => n.id);
    if (unreadIds.length === 0) return;
    await supabase.from("notifications").update({ read: true }).in("id", unreadIds);
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast.success("All notifications marked as read");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between page-header">
        <div>
          <h1 className="page-title">Notifications</h1>
          <p className="page-subtitle">{unreadCount} unread of {notifications.length} total</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllAsRead} className="btn-secondary gap-2 text-sm">
            <CheckCheck className="w-4 h-4" />
            Mark all read
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-16 text-center">
          <Bell className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-semibold text-lg mb-2">No notifications</h3>
          <p className="text-muted-foreground text-sm">You&apos;re all caught up! New alerts will appear here.</p>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-2xl divide-y divide-border overflow-hidden">
          {notifications.map((n, i) => {
            const config = TYPE_CONFIG[n.type] || TYPE_CONFIG.info;
            const Icon = config.icon;
            return (
              <motion.div
                key={n.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.03 }}
                onClick={() => !n.read && markAsRead(n.id)}
                className={cn(
                  "flex items-start gap-4 px-6 py-4 cursor-pointer transition-colors hover:bg-secondary/30",
                  !n.read && "bg-emerald-500/[0.03]"
                )}
              >
                <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0", config.color)}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium">{n.title}</p>
                    {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0" />}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                  <p className="text-xs text-muted-foreground/70 mt-1.5">{formatRelativeTime(n.created_at)}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
