export type UserRole = "user" | "admin" | "moderator";
export type WalletType = "metamask" | "walletconnect" | "coinbase" | "manual";
export type TransactionType = "send" | "receive" | "swap" | "stake" | "unstake" | "approve" | "mint" | "burn";
export type TransactionStatus = "pending" | "confirmed" | "failed" | "cancelled";
export type TicketStatus = "open" | "in_progress" | "resolved" | "closed";
export type TicketCategory = "general" | "technical" | "billing" | "security" | "wallet" | "account";
export type TicketPriority = "low" | "medium" | "high" | "urgent";
export type NotificationType = "info" | "success" | "warning" | "error" | "transaction" | "security";

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  avatar_url: string | null;
  role: UserRole;
  phone: string | null;
  bio: string | null;
  country: string | null;
  currency: string;
  created_at: string;
  updated_at: string;
}

export interface Wallet {
  id: string;
  user_id: string;
  address: string;
  wallet_type: WalletType;
  network: string;
  chain_id: number | null;
  label: string | null;
  is_primary: boolean;
  is_active: boolean;
  balance: string;
  connected_at: string;
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  wallet_id: string | null;
  type: TransactionType;
  amount: number;
  currency: string;
  usd_value: number | null;
  status: TransactionStatus;
  tx_hash: string | null;
  from_address: string | null;
  to_address: string | null;
  network: string;
  gas_fee: number | null;
  block_number: number | null;
  description: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  ticket_number: string;
  subject: string;
  message: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  admin_notes: string | null;
  resolved_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface TicketReply {
  id: string;
  ticket_id: string;
  user_id: string;
  message: string;
  is_staff: boolean;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  action_url: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface PortfolioSnapshot {
  id: string;
  user_id: string;
  total_value_usd: number;
  assets: CryptoAsset[];
  snapshot_date: string;
  created_at: string;
}

export interface CryptoAsset {
  symbol: string;
  name: string;
  amount: number;
  value_usd: number;
  price_usd: number;
  change_24h: number;
  logo?: string;
}

export interface DashboardStats {
  total_balance_usd: number;
  wallet_count: number;
  transaction_count: number;
  unread_notifications: number;
}
