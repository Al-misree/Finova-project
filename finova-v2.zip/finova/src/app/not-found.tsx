import Link from "next/link";
import { TrendingUp, Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="text-center max-w-md">
        <div className="w-14 h-14 rounded-2xl bg-emerald-500 flex items-center justify-center mx-auto mb-6">
          <TrendingUp className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-6xl font-display font-black mb-4 gradient-text">404</h1>
        <h2 className="text-xl font-display font-semibold mb-2">Page not found</h2>
        <p className="text-muted-foreground text-sm mb-8">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <Link href="/" className="btn-primary gap-2 inline-flex">
          <Home className="w-4 h-4" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
