import Link from "next/link";
import { TrendingUp } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel - decorative */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-secondary/30 flex-col items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(16,185,129,0.08)_0%,_transparent_70%)]" />

        <div className="relative z-10 max-w-md text-center">
          <Link href="/" className="flex items-center gap-2 justify-center mb-12">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-display font-bold">Finova</span>
          </Link>

          <h2 className="text-3xl font-display font-bold mb-4">
            Your Financial Command Center
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-10">
            Connect wallets, track your portfolio, and get AI-powered insights to grow your wealth intelligently.
          </p>

          <div className="space-y-3">
            {[
              "Real-time portfolio tracking across all wallets",
              "AI-powered financial insights and recommendations",
              "Bank-grade security with end-to-end encryption",
              "Support for 6+ blockchain networks",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 text-sm text-left bg-card/40 border border-border/50 rounded-xl px-4 py-3">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                </div>
                <span className="text-muted-foreground">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel - auth form */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-display font-bold">Finova</span>
          </div>

          {children}
        </div>
      </div>
    </div>
  );
}
