import { createClient } from "@/lib/supabase/server";
import { SupportView } from "@/components/dashboard/support-view";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Support" };

export default async function SupportPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: tickets } = await supabase
    .from("support_tickets")
    .select("*")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  return <SupportView tickets={tickets || []} userId={user!.id} />;
}
