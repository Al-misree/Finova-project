import { createClient } from "@/lib/supabase/server";
import { WalletsView } from "@/components/dashboard/wallets-view";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Wallets" };

export default async function WalletsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: wallets } = await supabase
    .from("wallets")
    .select("*")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false });

  return <WalletsView wallets={wallets || []} userId={user!.id} />;
}
