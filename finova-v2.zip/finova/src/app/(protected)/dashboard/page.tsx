import { createClient } from "@/lib/supabase/server";
import { DashboardOverview } from "@/components/dashboard/dashboard-overview";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const [profileResult, walletsResult, transactionsResult, notificationsResult] =
    await Promise.all([
      supabase.from("profiles").select("*").eq("id", user!.id).single(),
      supabase.from("wallets").select("*").eq("user_id", user!.id).eq("is_active", true),
      supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false })
        .limit(10),
      supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user!.id)
        .eq("read", false)
        .limit(5),
    ]);

  return (
    <DashboardOverview
      profile={profileResult.data}
      wallets={walletsResult.data || []}
      transactions={transactionsResult.data || []}
      unreadNotifications={notificationsResult.data || []}
    />
  );
}
