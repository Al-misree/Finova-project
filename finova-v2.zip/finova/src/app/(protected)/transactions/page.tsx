import { createClient } from "@/lib/supabase/server";
import { TransactionsView } from "@/components/dashboard/transactions-view";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Transactions" };

export default async function TransactionsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: transactions } = await supabase
    .from("transactions")
    .select("*")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false })
    .limit(50);

  return <TransactionsView transactions={transactions || []} />;
}
