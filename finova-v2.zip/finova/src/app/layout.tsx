import type { Metadata } from "next";
import { Inter, Sora } from "next/font/google";
import "@/styles/globals.css";
import { ThemeProvider } from "@/components/shared/theme-provider";
import { QueryProvider } from "@/components/shared/query-provider";
import { Toaster } from "sonner";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Finova — AI-Powered Financial Platform",
    template: "%s | Finova",
  },
  description:
    "Manage your finances and crypto portfolio with AI-powered insights. Connect wallets, track transactions, and grow your wealth with Finova.",
  keywords: ["fintech", "crypto", "DeFi", "wallet", "portfolio", "AI", "finance"],
  authors: [{ name: "Finova" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://finova.app",
    title: "Finova — AI-Powered Financial Platform",
    description: "Manage your finances and crypto portfolio with AI-powered insights.",
    siteName: "Finova",
  },
  twitter: {
    card: "summary_large_image",
    title: "Finova — AI-Powered Financial Platform",
    description: "Manage your finances and crypto portfolio with AI-powered insights.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${sora.variable} font-sans`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <QueryProvider>
            {children}
            <Toaster
              position="top-right"
              richColors
              closeButton
              toastOptions={{
                style: {
                  background: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  color: "hsl(var(--foreground))",
                },
              }}
            />
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
