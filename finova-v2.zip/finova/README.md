# Finova V2 — AI-Powered Fintech Platform

A production-grade fintech and crypto portfolio management platform built with Next.js 15, TypeScript, Supabase, and Web3 tooling.

## Tech Stack

- **Framework:** Next.js 15 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS + Shadcn-style components
- **Database/Auth:** Supabase (PostgreSQL + Row Level Security)
- **Data fetching:** React Query
- **Forms:** React Hook Form + Zod
- **Web3:** Wagmi + Viem + WalletConnect
- **Deployment:** Netlify

---

## 1. Prerequisites

- Node.js 20+
- A free [Supabase](https://supabase.com) project
- A free [WalletConnect Cloud](https://cloud.reown.com) project ID
- A [Netlify](https://netlify.com) account

---

## 2. Set up Supabase

1. Create a new project at [supabase.com](https://supabase.com).
2. Go to **SQL Editor** and run the migration file at:
   `supabase/migrations/001_initial_schema.sql`
   This creates all tables, RLS policies, triggers, and indexes.
3. Go to **Storage** and create a public bucket named `avatars` (used for profile pictures). The SQL for its policies is commented at the bottom of the migration file — uncomment and run it after creating the bucket.
4. Go to **Authentication → URL Configuration** and set:
   - Site URL: your deployed Netlify URL (e.g. `https://your-app.netlify.app`)
   - Redirect URLs: add `https://your-app.netlify.app/**` and `http://localhost:3000/**`
5. Go to **Project Settings → API** and copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

---

## 3. Set up WalletConnect

1. Create a project at [cloud.reown.com](https://cloud.reown.com) (formerly WalletConnect Cloud).
2. Copy the **Project ID** → `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`

---

## 4. Local Development

```bash
npm install
cp .env.local.example .env.local
# Fill in your real values in .env.local
npm run dev
```

Visit `http://localhost:3000`.

---

## 5. Deploy to Netlify

### Option A — Netlify UI (recommended)

1. Push this project to a GitHub/GitLab/Bitbucket repository.
2. In Netlify: **Add new site → Import an existing project**.
3. Connect your repo. Netlify will auto-detect `netlify.toml`.
4. Under **Site settings → Environment variables**, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`
5. Deploy. Netlify will run `npm run build` automatically using the `@netlify/plugin-nextjs` plugin declared in `netlify.toml`.

### Option B — Netlify CLI

```bash
npm install -g netlify-cli
netlify init
netlify env:set NEXT_PUBLIC_SUPABASE_URL "your_value"
netlify env:set NEXT_PUBLIC_SUPABASE_ANON_KEY "your_value"
netlify env:set NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID "your_value"
netlify deploy --prod
```

> **Important:** After deploying, go back to Supabase → Authentication → URL Configuration and update the Site URL / Redirect URLs to match your live Netlify domain, or email verification and password reset links will point to the wrong place.

---

## 6. Project Structure

```
src/
├── app/
│   ├── (auth)/              # Public auth pages: login, register, forgot/reset password
│   ├── (protected)/         # Private dashboard pages (guarded by middleware + layout)
│   ├── api/auth/callback/   # Supabase email-link exchange route
│   ├── page.tsx             # Public landing page
│   └── layout.tsx           # Root layout (theme, query, toaster providers)
├── components/
│   ├── landing/              # Landing page sections
│   ├── auth/                  # Auth forms
│   ├── dashboard/             # Dashboard shell + feature views
│   └── shared/                 # Theme provider/toggle, query provider
├── lib/
│   ├── supabase/             # Browser + server Supabase clients
│   ├── validations/           # Zod schemas
│   ├── types/                  # Shared TypeScript types
│   └── utils/                   # Formatting helpers
└── middleware.ts             # Route protection (redirects unauthenticated users)

supabase/
└── migrations/001_initial_schema.sql   # Full DB schema, RLS, triggers, indexes
```

## 7. User Flow

1. **Landing page** (`/`) is public and shown first — Hero, Features, Security, How It Works, Testimonials, FAQ, Pricing, About, Contact.
2. **Register** (`/register`) creates a Supabase Auth user → sends email verification → redirects to `/login`.
3. **Login** (`/login`) authenticates via Supabase, creates a session, redirects to `/dashboard`.
4. **Middleware** (`src/middleware.ts`) blocks direct access to any protected route (`/dashboard`, `/wallets`, `/transactions`, `/support`, `/settings`, `/profile`, `/notifications`) for unauthenticated users, redirecting them to `/login`.
5. **Logout** destroys the session and redirects to `/`.

All data access is protected at the database level via Postgres Row Level Security — every table policy checks `auth.uid()` against the row owner.

## 8. Notes

- This is wired for **real Supabase Authentication** — no mock auth.
- Wallet "connect" in `/wallets` currently stores wallet addresses you enter manually in the database (so you can fully test the flow without a browser wallet extension). To wire up live MetaMask/WalletConnect/Coinbase Wallet connections, add Wagmi connectors in a client provider and call the existing `wallets` insert logic with the connected address.
- Crypto balances and prices on the dashboard are illustrative placeholders — swap in a price feed (e.g. CoinGecko API) and on-chain balance reads (via Viem) for live data.
